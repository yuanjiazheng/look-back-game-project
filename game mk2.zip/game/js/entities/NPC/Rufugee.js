class Rufugee extends NPC {
    constructor(x, y, resourceManager) {
        super(x, y, 128, 128, "rufugee", "friendly");
        this.speed = 0.2;
        this.detectionRange = 200;
        this.interactionRange = 40;
        
        // 存储资源管理器引用
        this.resourceManager = resourceManager;
        
        // 添加精确的 hitbox
        this.addHitbox(50,35,25,45, "vulnerable");
        
        // 加载动画
        this.loadAnimations();
    }
    
    loadAnimations() {
        const RufugeeIdle = this.resourceManager.getResource('PlayerIdlesheet');
        const RufugeeWalk = this.resourceManager.getResource('PlayerWalksheet');
        
        if (RufugeeIdle&&RufugeeWalk) {
            this.animator.addAnimation('idle', new Animation(
                RufugeeIdle, 128, 128, 150, [0, 1, 2, 3, 4, 5], true,
            ));
            
            this.animator.addAnimation('walk', new Animation(
                RufugeeWalk, 128, 128, 100, [0, 1, 2, 3, 4, 5, 6, 7], true,
            ));
            
            this.animator.playAnimation('idle');
        }
    }
    
     updateAI(game) {
    // 首先检测附近的金币
    
    const goldEntities = game.goldCollectionSystem.goldEntities;
    let nearestGold = null;
    let minDistance = this.detectionRange;
    
    for (const gold of goldEntities) {
        if (!gold.isActive || gold.collected) continue;
        
        const distance = this.getDistanceTo(gold);
        if (distance < minDistance) {
            minDistance = distance;
            nearestGold = gold;
        }
    }
    
    if (nearestGold) {
        // 如果检测到金币，设置金币为目标，并切换到跟随金币状态
        this.setTarget(nearestGold);
        this.behaviorState = "follow";
    } else {
        // 如果没有金币，则检测玩家
        const player = game.player;
        const playerCollisions = this.detectEntitiesInRange(game, this.detectionRange, "vulnerable");
        
        if (playerCollisions.length > 0 && playerCollisions[0].entity.type === "player") {
            this.setTarget(player);
            
            if (this.isInRange(player, this.interactionRange)) {
                this.behaviorState = "idle";
            } else {
                this.behaviorState = "follow";
            }
        } else {
            this.clearTarget();
            this.behaviorState = "idle";
        }
    }
    
    super.updateAI(game);
}

// 添加计算距离的方法
getDistanceTo(entity) {
    const myHitbox = this.hitboxes[0];
    const targetHitbox = entity.hitboxes[0];
    
    const myCenterX = myHitbox.x + myHitbox.width / 2;
    const myCenterY = myHitbox.y + myHitbox.height / 2;
    const targetCenterX = targetHitbox.x + targetHitbox.width / 2;
    const targetCenterY = targetHitbox.y + targetHitbox.height / 2;
    
    const dx = targetCenterX - myCenterX;
    const dy = targetCenterY - myCenterY;
    return Math.sqrt(dx * dx + dy * dy);
}
}